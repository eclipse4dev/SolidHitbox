package org.vee.solid_hitbox.mixin;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public class EntityMixin {

    @Inject(method = "isCollidable", at = @At("HEAD"), cancellable = true)
    private void return_boolean(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(true);
    }

}
